
class ReplyTranslate:
    def dict_maker(ba,v):
        r ={}
        for n,byt in enumerate(v):
            for m,val in enumerate(byt):
                if val !="X":
                    r[val] = ba[n]>>(7-m)&1
        return r

    def get_ph_status(ba):
        v=[['FILTER_MATCH_PEND','FILTER_MISS_PEND','X','PACKET_RX_PEND','CRC_ERROR_PEND','ALT_CRC_ERROR_PEND','X','RX_FIFO_ALMOST_FULL_PEND'],\
            ['FILTER_MATCH','FILTER_MISS','X','PACKET_RX','CRC_ERROR','ALT_CRC_ERROR','X','RX_FIFO_ALMOST_FULL']]
        r = ReplyTranslate.dict_maker(ba,v) 
        return r
 
    def get_chip_status(ba):
        cmd_error_status = {0:"CMD_ERROR_NONE",16: "CMD_ERROR_BAD_COMMAND",17:"CMD_ERROR_BAD_ARG", 18: "CMD_ERROR_COMMAND_BUSY", 19:"CMD_ERROR_INVALID_STATE",49:"CMD_ERROR_BAD_BOOTMODE",64: "CMD_ERROR_BAD_PROPERTY"}
        v= [['X','CAL_PEND','FIFO_UNDERFLOW_OVERFLOW_ERROR_PEND','STATE_CHANGE_PEND','CMD_ERROR_PEND','CHIP_READY_PEND','LOW_BATT_PEND','WUT_PEND'],\
        ['X','CAL','FIFO_UNDERFLOW_OVERFLOW_ERROR','STATE_CHANGE','CMD_ERROR','CHIP_READY','LOW_BATT','WUT']]
        r = ReplyTranslate.dict_maker(ba,v)
        r["CMD_ERR_STATUS"] = ba[2]
        if ba[2] in cmd_error_status.keys():
            r["CMD_ERR_STATUS"] = cmd_error_status[ba[2]]
        r["CMD_ERROR_CMD_ID"] = ba[3]
        return r

    def get_int_status(ba):
        v= [['X','X','X','X','X','CHIP_INT_PEND','MODEM_INT_PEND','PH_INT_PEND'],\
    ['X','X','X','X','X','CHIP_INT_STATUS','MODEM_INT_STATUS','PH_INT_STATUS'],\
    ['FILTER_MATCH_PEND','FILTER_MISS_PEND','X','PACKET_RX_PEND','CRC_ERROR_PEND','ALT_CRC_ERROR_PEND','X','RX_FIFO_ALMOST_FULL_PEND'],\
    ['FILTER_MATCH','FILTER_MISS','X','PACKET_RX','CRC_ERROR','ALT_CRC_ERROR','X','RX_FIFO_ALMOST_FULL'],\
    ['RSSI_LATCH_PEND','POSTAMBLE_DETECT_PEND','INVALID_SYNC_PEND','RSSI_JUMP_PEND','RSSI_PEND','INVALID_PREAMBLE_PEND','PREAMBLE_DETECT_PEND','SYNC_DETECT_PEND'],\
    ['RSSI_LATCH','POSTAMBLE_DETECT','INVALID_SYNC','RSSI_JUMP','RSSI','INVALID_PREAMBLE','PREAMBLE_DETECT','SYNC_DETECT'],\
    ['X','CAL_PEND','FIFO_UNDERFLOW_OVERFLOW_ERROR_PEND','STATE_CHANGE_PEND','CMD_ERROR_PEND','CHIP_READY_PEND','LOW_BATT_PEND','WUT_PEND'],\
    ['X','CAL','FIFO_UNDERFLOW_OVERFLOW_ERROR','STATE_CHANGE','CMD_ERROR','CHIP_READY','LOW_BATT','WUT']]
        r= ReplyTranslate.dict_maker(ba,v)
        return r

    def get_modem_status(ba):
        v=[['RSSI_LATCH_PEND','POSTAMBLE_DETECT_PEND','INVALID_SYNC_PEND','RSSI_JUMP_PEND','RSSI_PEND','INVALID_PREAMBLE_PEND','PREAMBLE_DETECT_PEND','SYNC_DETECT_PEND'],\
    ['RSSI_LATCH','POSTAMBLE_DETECT','INVALID_SYNC','RSSI_JUMP','RSSI','INVALID_PREAMBLE','PREAMBLE_DETECT','SYNC_DETECT']]
        r = ReplyTranslate.dict_maker(ba,v)
        r["CURR_RSSI"] = ba[2]
        r["LATCH_RSSI"] = ba[3]
        r["ANT1_RSSI"] = ba[4]
        r["ANT2_RSSI"] = ba[5]
        r["AFC_FREQ_OFFSET"] = (ba[6]<<8)+ba[7] 
        return r
    