import machine
import micropython
micropython.alloc_emergency_exception_buf(1000)
import time
from ReplyTranslate import ReplyTranslate
from upysh import clear
sdn = 23
cts = 19 #21
sck =14
mosi = 113
miso = 12
sel = 15

power_on = 32
machine.freq(240000000)


RF_POWER_UP=[ 0x02,0x01,0x01,0x01,0xc9,0xc3,0x80]
RF_GPIO_PIN_CFG=[ 0x13,0x00,0x11,0x00,0x14,0x08,0x27]
RF_GLOBAL_XO_TUNE_1=[ 0x11,0x00,0x01,0x00,0x52]
RF_GLOBAL_CONFIG_1=[ 0x11,0x00,0x01,0x03,0x20]
RF_PREAMBLE_CONFIG_1=[ 0x11,0x10,0x01,0x04,0x21]
RF_MODEM_MOD_TYPE_12=[ 0x11,0x20,0x0c,0x00,0x0b,0x00,0x07,0x02,0x71,0x00,0x05,0xc9,0xc3,0x80,0x00,0x00]
RF_MODEM_FREQ_DEV_0_1=[ 0x11,0x20,0x01,0x0c,0xd2]
RF_MODEM_MDM_CTRL_12=[ 0x11,0x20,0x0c,0x19,0x00,0x08,0x02,0x80,0x00,0xb0,0x10,0x0c,0xe8,0x00,0x4e,0x06]
RF_MODEM_BCR_NCO_OFFSET_1_12=[ 0x11,0x20,0x0c,0x25,0x8d,0xb9,0x00,0x00,0x02,0xc0,0x08,0x00,0x12,0x00,0x69,0x01]
RF_MODEM_AFC_LIMITER_0_2=[ 0x11,0x20,0x02,0x31,0x5c,0xa0]
RF_MODEM_AGC_CONTROL_1=[ 0x11,0x20,0x01,0x35,0xe0]
RF_MODEM_AGC_WINDOW_SIZE_12=[ 0x11,0x20,0x0c,0x38,0x11,0x11,0x11,0x80,0x1a,0x20,0x00,0x00,0x28,0x0c,0xa4,0x23]
RF_MODEM_RAW_CONTROL_5=[ 0x11,0x20,0x05,0x45,0x03,0x00,0x85,0x01,0x00]
RF_MODEM_RSSI_JUMP_THRESH_4=[ 0x11,0x20,0x04,0x4b,0x06,0x09,0x10,0x40]
RF_MODEM_RAW_SEARCH2_2=[ 0x11,0x20,0x02,0x50,0x94,0x0d]
RF_MODEM_SPIKE_DET_2=[ 0x11,0x20,0x02,0x54,0x03,0x07]
RF_MODEM_RSSI_MUTE_1=[ 0x11,0x20,0x01,0x57,0x00]
RF_MODEM_DSA_CTRL1_5=[ 0x11,0x20,0x05,0x5b,0x40,0x04,0x04,0x78,0x20]
RF_MODEM_CHFLT_RX1_CHFLT_COE13_7_0_12=[ 0x11,0x21,0x0c,0x00,0x7e,0x64,0x1b,0xba,0x58,0x0b,0xdd,0xce,0xd6,0xe6,0xf6,0x00]
RF_MODEM_CHFLT_RX1_CHFLT_COE1_7_0_12=[ 0x11,0x21,0x0c,0x0c,0x03,0x03,0x15,0xf0,0x3f,0x00,0x7e,0x64,0x1b,0xba,0x58,0x0b]
RF_MODEM_CHFLT_RX2_CHFLT_COE7_7_0_12=[ 0x11,0x21,0x0c,0x18,0xdd,0xce,0xd6,0xe6,0xf6,0x00,0x03,0x03,0x15,0xf0,0x3f,0x00]
RF_SYNTH_PFDCP_CPFF_7=[ 0x11,0x23,0x07,0x00,0x2c,0x0e,0x0b,0x04,0x0c,0x73,0x03]
RF_FREQ_CONTROL_INTE_8=[ 0x11,0x40,0x08,0x00,0x3b,0x0b,0x00,0x00,0x28,0xf6,0x20,0xfa]
RF_START_RX=[ 0x32,0x00,0x00,0x00,0x00,0x00,0x00,0x00]
RF_IRCAL=[ 0x17,0x56,0x10,0xca,0xf0]
RF_IRCAL_1=[ 0x17,0x13,0x10,0xca,0xf0]
RF_GLOBAL_CLK_CFG_1=[ 0x11,0x00,0x01,0x01,0x00]
RF_GLOBAL_CONFIG_1_1=[ 0x11,0x00,0x01,0x03,0x20]
RF_INT_CTL_ENABLE_1=[ 0x11,0x01,0x01,0x00,0x02]
RF_INT_CTL_ENABLE_SELBST=[ 0x11,0x01,0x01,0x02,0x18]
RF_FRR_CTL_A_MODE_4=[ 0x11,0x02,0x04,0x00,0x0a,0x09,0x00,0x00]
RF_PREAMBLE_CONFIG_STD_1_1=[ 0x11,0x10,0x01,0x01,0x0b]
RF_SYNC_CONFIG_6=[ 0x11,0x11,0x06,0x00,0x01,0xff,0xff,0x00,0x00,0x00]
RF_PKT_CONFIG1_1=[ 0x11,0x12,0x01,0x06,0x40]
RF_MODEM_MOD_TYPE_12_1=[ 0x11,0x20,0x0c,0x00,0x0b,0x00,0x07,0x05,0xdc,0x00,0x05,0xc9,0xc3,0x80,0x00,0x01]
RF_MODEM_FREQ_DEV_0_1_1=[ 0x11,0x20,0x01,0x0c,0xf7]
RF_MODEM_MDM_CTRL_12_1=[ 0x11,0x20,0x0c,0x19,0x80,0x08,0x02,0x80,0x00,0x70,0x20,0x00,0xe8,0x00,0x62,0x05]
RF_MODEM_BCR_NCO_OFFSET_1_12_1=[ 0x11,0x20,0x0c,0x25,0x3e,0x2d,0x02,0x9d,0x00,0xc2,0x00,0x54,0x23,0x81,0x01,0x02]
RF_MODEM_AFC_LIMITER_0_2_1=[ 0x11,0x20,0x02,0x31,0x4e,0x80]
RF_MODEM_AGC_CONTROL_1_1=[ 0x11,0x20,0x01,0x35,0xe0]
RF_MODEM_AGC_WINDOW_SIZE_12_1=[ 0x11,0x20,0x0c,0x38,0x11,0x15,0x15,0x80,0x1a,0x20,0x00,0x00,0x28,0x0c,0x84,0x23]
RF_MODEM_RAW_CONTROL_10=[ 0x11,0x20,0x0a,0x45,0x8f,0x00,0x6a,0x01,0x00,0x80,0x06,0x03,0x18,0x40]
RF_MODEM_RAW_SEARCH2_2_1=[ 0x11,0x20,0x02,0x50,0x94,0x0d]
RF_MODEM_SPIKE_DET_2_1=[ 0x11,0x20,0x02,0x54,0x03,0x07]
RF_MODEM_RSSI_MUTE_1_1=[ 0x11,0x20,0x01,0x57,0x00]
RF_MODEM_RSSI_HYSTERESIS=[ 0x11,0x20,0x01,0x56,0xff]
RF_MODEM_DSA_CTRL1_5_1=[ 0x11,0x20,0x05,0x5b,0x40,0x04,0x04,0x78,0x20]
RF_MODEM_CHFLT_RX1_CHFLT_COE13_7_0_12_1=[ 0x11,0x21,0x0c,0x00,0xff,0xc4,0x30,0x7f,0xf5,0xb5,0xb8,0xde,0x05,0x17,0x16,0x0c]
RF_MODEM_CHFLT_RX1_CHFLT_COE1_7_0_12_1=[ 0x11,0x21,0x0c,0x0c,0x03,0x00,0x15,0xff,0x00,0x00,0xff,0xc4,0x30,0x7f,0xf5,0xb5]
RF_MODEM_CHFLT_RX2_CHFLT_COE7_7_0_12_1=[ 0x11,0x21,0x0c,0x18,0xb8,0xde,0x05,0x17,0x16,0x0c,0x03,0x00,0x15,0xff,0x00,0x00]
RF_SYNTH_PFDCP_CPFF_7_1=[0x11,0x23,0x07,0x00,0x2c,0x0e,0x0b,0x04,0x0c,0x73,0x03]
RF_FREQ_CONTROL_INTE_8_1=[ 0x11,0x40,0x08,0x00,0x3f,0x0e,0x51,0xeb,0x28,0xf6,0x20,0xfa]
settings = [RF_POWER_UP,RF_GPIO_PIN_CFG,RF_GLOBAL_XO_TUNE_1,RF_GLOBAL_CONFIG_1,RF_PREAMBLE_CONFIG_1,RF_MODEM_MOD_TYPE_12,RF_MODEM_FREQ_DEV_0_1,RF_MODEM_MDM_CTRL_12,RF_MODEM_BCR_NCO_OFFSET_1_12,RF_MODEM_AFC_LIMITER_0_2,RF_MODEM_AGC_CONTROL_1,RF_MODEM_AGC_WINDOW_SIZE_12,RF_MODEM_RAW_CONTROL_5,RF_MODEM_RSSI_JUMP_THRESH_4,RF_MODEM_RAW_SEARCH2_2,RF_MODEM_SPIKE_DET_2,RF_MODEM_RSSI_MUTE_1,RF_MODEM_DSA_CTRL1_5,RF_MODEM_CHFLT_RX1_CHFLT_COE13_7_0_12,RF_MODEM_CHFLT_RX1_CHFLT_COE1_7_0_12,RF_MODEM_CHFLT_RX2_CHFLT_COE7_7_0_12,RF_SYNTH_PFDCP_CPFF_7,RF_FREQ_CONTROL_INTE_8,RF_START_RX,RF_IRCAL,RF_IRCAL_1,RF_GLOBAL_CLK_CFG_1,RF_GLOBAL_CONFIG_1_1,RF_INT_CTL_ENABLE_1,RF_INT_CTL_ENABLE_SELBST,RF_FRR_CTL_A_MODE_4,RF_PREAMBLE_CONFIG_STD_1_1,RF_SYNC_CONFIG_6,RF_PKT_CONFIG1_1,RF_MODEM_MOD_TYPE_12_1,RF_MODEM_FREQ_DEV_0_1_1,RF_MODEM_MDM_CTRL_12_1,RF_MODEM_BCR_NCO_OFFSET_1_12_1,RF_MODEM_AFC_LIMITER_0_2_1,RF_MODEM_AGC_CONTROL_1_1,RF_MODEM_AGC_WINDOW_SIZE_12_1,RF_MODEM_RAW_CONTROL_10,RF_MODEM_RAW_SEARCH2_2_1,RF_MODEM_SPIKE_DET_2_1,RF_MODEM_RSSI_MUTE_1_1,RF_MODEM_RSSI_HYSTERESIS,RF_MODEM_DSA_CTRL1_5_1,RF_MODEM_CHFLT_RX1_CHFLT_COE13_7_0_12_1,RF_MODEM_CHFLT_RX1_CHFLT_COE1_7_0_12_1,RF_MODEM_CHFLT_RX2_CHFLT_COE7_7_0_12_1,RF_SYNTH_PFDCP_CPFF_7_1,RF_FREQ_CONTROL_INTE_8_1]
command_order = ['RF_POWER_UP', 'RF_GPIO_PIN_CFG', 'RF_GLOBAL_XO_TUNE_1', 'RF_GLOBAL_CONFIG_1', 'RF_PREAMBLE_CONFIG_1', 'RF_MODEM_MOD_TYPE_12', 'RF_MODEM_FREQ_DEV_0_1', 'RF_MODEM_MDM_CTRL_12', 'RF_MODEM_BCR_NCO_OFFSET_1_12', 'RF_MODEM_AFC_LIMITER_0_2', 'RF_MODEM_AGC_CONTROL_1', 'RF_MODEM_AGC_WINDOW_SIZE_12', 'RF_MODEM_RAW_CONTROL_5', 'RF_MODEM_RSSI_JUMP_THRESH_4', 'RF_MODEM_RAW_SEARCH2_2', 'RF_MODEM_SPIKE_DET_2', 'RF_MODEM_RSSI_MUTE_1', 'RF_MODEM_DSA_CTRL1_5', 'RF_MODEM_CHFLT_RX1_CHFLT_COE13_7_0_12', 'RF_MODEM_CHFLT_RX1_CHFLT_COE1_7_0_12', 'RF_MODEM_CHFLT_RX2_CHFLT_COE7_7_0_12', 'RF_SYNTH_PFDCP_CPFF_7', 'RF_FREQ_CONTROL_INTE_8', 'RF_START_RX', 'RF_IRCAL', 'RF_IRCAL_1', 'RF_GLOBAL_CLK_CFG_1', 'RF_GLOBAL_CONFIG_1_1', 'RF_INT_CTL_ENABLE_1', 'RF_INT_CTL_ENABLE_SELBST', 'RF_FRR_CTL_A_MODE_4', 'RF_PREAMBLE_CONFIG_STD_1_1', 'RF_SYNC_CONFIG_6', 'RF_PKT_CONFIG1_1', 'RF_MODEM_MOD_TYPE_12_1', 'RF_MODEM_FREQ_DEV_0_1_1', 'RF_MODEM_MDM_CTRL_12_1', 'RF_MODEM_BCR_NCO_OFFSET_1_12_1', 'RF_MODEM_AFC_LIMITER_0_2_1', 'RF_MODEM_AGC_CONTROL_1_1', 'RF_MODEM_AGC_WINDOW_SIZE_12_1', 'RF_MODEM_RAW_CONTROL_10', 'RF_MODEM_RAW_SEARCH2_2_1', 'RF_MODEM_SPIKE_DET_2_1', 'RF_MODEM_RSSI_MUTE_1_1', 'RF_MODEM_RSSI_HYSTERESIS', 'RF_MODEM_DSA_CTRL1_5_1', 'RF_MODEM_CHFLT_RX1_CHFLT_COE13_7_0_12_1', 'RF_MODEM_CHFLT_RX1_CHFLT_COE1_7_0_12_1', 'RF_MODEM_CHFLT_RX2_CHFLT_COE7_7_0_12_1', 'RF_SYNTH_PFDCP_CPFF_7_1', 'RF_FREQ_CONTROL_INTE_8_1']
command_dict  = {}
for a,b in zip(command_order,settings):
    command_dict[a] = [hex(x) for x in b] 



def makepinout(n):
    return machine.Pin(n,machine.Pin.OUT)
def makepinin(n):
    return machine.Pin(n,machine.Pin.IN)
    
class si4362:
    def dict_print(dict):
        for key, value in dict.items():
            if value:
                if value == 1:
                    print(key)
                else:
                    print(key," :\t",value)
    def ba_to_filled_one_string(ba):
        a = [i+256 for i in ba]
        b = [str(bin(i))[3:]for i in a]
        return "".join(b)
    
    def ba_map_array(ba,arr):
        strarr = si4362.ba_to_filled_one_string(ba)
        for n,c in enumerate(arr):
            if strarr[n]=='1':
                print(c)

    def __init__(self,sdn=sdn,cts=cts,sel=sel,power_on=power_on,sck=sck,mosi=mosi,miso=miso):
        sdn = sdn #22
        cts = cts #21
        sck = sck
        mosi = mosi
        miso = miso                               
        sel = sel
        self.power_on = makepinout(power_on)
        self._pin_SDN = sdn
        self._pin_CTS = cts
        self.cts = makepinin(cts)
        self.sdn = makepinout(sdn)
        self.sel = makepinout(sel)
        self.command_order = [] 
        self.command_dict = {}
        
        self._spi = machine.SPI(baudrate=1000000,
                  polarity=0,
                  phase=0,
                  bits=8,
                  firstbit=machine.SPI.MSB,
                  sck=machine.Pin(sck),
                  mosi=machine.Pin(mosi),
                  miso=machine.Pin(miso))
        self.enable()
    def load_conf(self):
        #self.command_order ,self.command_dict = configheaderparser.from_config_file("radio_config.h")
        self.command_order = command_order
        self.command_dict = command_dict
        print(self.command_order)
        print(self.command_dict)
    def tune(self):
        self.set_dev_state(3)
        time.sleep(0.5)
        self.set_dev_state(6)
        time.sleep(1)
        self.set_dev_state(3)
        time.sleep(0.5)
        self.set_dev_state(8)
        print("RSSI",self.get_current_rssi())  
    def send_command(self):
        while True:
            for n,c in enumerate(self.command_order):
                print(n,"\t",c)
            k = input("\nChoose Command , -1 to abort\n")
            if k =="-1":
                return
            command =[int(y,16) for y in self.command_dict[self.command_order[int(k)]]]
            self.send_command(command)

    def open(self):
        pass
    def setup(self,int_stat=False,start=False,end=False,func=None):
        self.power_on.value(0)
        time.sleep(0.5)
        self.power_on.value(1)
        time.sleep(0.5)
        print("powered")
        self.load_conf()
        if start == False:
            self.open()
            self.reset()
        com_a = self.command_order 
        com_d =self.command_dict
        com_s = [[int(y,16) for y in com_d[x]] for x in com_a]
        #self.power_up()
    #s.set_rssi_thresh(int(100))
        for n,c in enumerate(com_s):
            time.sleep(0.01)

            if func:
                func()
            if start:
                if n < start:
                    continue 
            if end:
                if end < n:
                    return 
            
            print(".",end="")
            if int_stat:
                command_info(self)
                k = input("weiter?")

            ch = [k for k in c]
            if  ch[0] == 0x11:
                #continue
                zu_schreiben = ch[4:]
                self.set_property(ch[1],ch[3],ch[4:])
            else:
                arg2 = None
                if len(ch)>1:
                    arg2 = ch[2:]
                self.command(ch[0],arg2,1)
            if n==0:
                time.sleep(0.05)
            time.sleep(0.01)

            cs = ReplyTranslate.get_chip_status(self.command(0x23,[],5))

            if cs["CMD_ERR_STATUS"] !="CMD_ERROR_NONE":
                print("\n")
                print("CommandError")
                print(cs)
                print("CommandNR:",n)
                print("Command:",ch)
                k = input("Continue y/n?")
                if k!="y":
                    print("abort")
                    return
        print("\n")
                 
        
    def reset(self):
        self.sdn.on()
        self.sdn.off()
        while not self.cts.value():
            pass 
        print("Powered on after Reset")
    
    def enable(self):
        self.sel.on()

    def disable(self):
        self.sel.off()

    def close(self):
        #self._spi.close()
        #GPIO.cleanup()
        pass
    def power_up(self, func=1):
        self.command(0x02, [func, 0x00, 0x01, 0xc9, 0xc3, 0x80])
    
    def command(self, cmd, input=None, output_bytes=0):
        if cmd not in  []: 
            pass 

        cmd_in = [cmd]
        if input is not None:
            cmd_in = cmd_in + input
        if len(cmd_in) == 1:
            cmd_in = [cmd_in[0],]
        #print(cmd_in)
        while not self.cts.value():
            pass
        #print("cmd_in",cmd_in)
        cmd_in = bytearray(cmd_in)
        self.disable()
        self._spi.write(cmd_in)
        self.enable()
        if output_bytes > 0:
            cmd_out = [0x44, 0]
            cmd_out = cmd_out + [0] * output_bytes
            #print("com_out extended",cmd_out)
            while not self.cts.value():
                pass
            cmd_out=bytearray(cmd_out)
            res= bytearray([0 for x in cmd_out])
            self.disable()
            self._spi.write_readinto(cmd_out,res)       
            self.enable()
            return res[2:]
    def get_gpio_config(self):
        answ = self.command(0x14,input=[0 for i in range(7)],output_bytes=7)
        return answ
    def part_info(self):
        data = self.command(0x01, output_bytes=8)
        out = {}
        out['chiprev'] = data[0]
        out['part'] = data[1] * 256 + data[2]
        out['pbuild'] = data[3]
        out['id'] = data[4] * 256 + data[5]
        out['customer'] = data[6]
        out['romid'] = data[7]
        return out
    def func_info(self):
        data = self.command(0x10, output_bytes=6)
        out = {}
        out['revext'] = data[0]
        out['revbranch'] = data[1]
        out['revint'] = data[2]
        out['patch'] = data[3] * 256 + data[4]
        out['func'] = data[5]
        if data[5] == 0:
            out['image'] = 'BOOT'
        elif data [5] == 1:
            out['image'] = 'MAIN'
        else:
            out['image'] = 'IMAGE%d' % data[5]
        return out
    def set_property(self, group, start_prop, prop_values):
        cmd_data = [group, len(prop_values), start_prop]
        cmd_data.extend(prop_values)
        self.command(0x11, cmd_data, 0)
    def get_property(self, group, num_props, start_prop):
        out = self.command(0x12, [group, num_props, start_prop], num_props)
        return out
    def get_chip_status(self, clr_pending_mask=None):
        if clr_pending_mask is None:
            data = self.command(0x23, output_bytes=5)
        else:
            data = self.command(0x23, [clr_pending_mask], 5)
        out = {}
        out['chip_pend'] = data[0]
        out['chip_status'] = data[1]
        out['cmd_err_status'] = data[2]
        out['cmd_err_cmd_id'] = data[3]
        out['info_flags'] = data[4]
        return out
    def fifo_info(self, reset_mask=0):
        data = self.command(0x15, [reset_mask], 2)
        out = {}
        out['rx_fifo_count'] = data[0]
        out['tx_fifo_space'] = data[1]
        return out
    def set_dev_state(self,state):
        return self.command(0x34,input=[state],output_bytes=1)
    def get_dev_state(self):
        trans = ["NOCHANGE","SLEEP","SPI_ACTIVE","READY","unknown","unkown","RX_TUNE","unknown","RX"]
        return trans[self.command(0x33,output_bytes=1)[0]]
        #return self.command(0x33,output_bytes=2)
    def peek(self, addr):
        out = self.command(0xf0, [int(addr / 256), int(addr % 256)], 1)
        return out[0]

    def start_rx(self):
        return self.command(0x32,[0 for i in range(7)])
    def poke(self, addr, value):
        self.command(0xf1, [int(addr / 256), int(addr % 256), value], 0)
    def get_int_status(self,clear=True):
        all_not_clear = [0xdd,0xff,0x7f]
        clr = [0xff,0xff,0xff]
        if clear:
            clr = []
        #int_status =  self.command(0x20,input=all_not_clear,output_bytes=9)
        int_status = self.command(0x20,clr,8)
        return int_status
    def clear_int(self):
        self.command(0x20,[],0)

    def dump(self, start=0, end=65535):
        if end is None:
            end = 0xffff
        addr = start
        peek_out = []
        while addr <= end:
            peek_in = []
            for x in range(7):
                if addr + x <= end:
                    peek_in.append(int((addr + x) / 256))
                    peek_in.append(int((addr + x) % 256))
            peek_out.extend(self.command(0xf0, peek_in, int(len(peek_in)/2)))
            addr += 7
        return peek_out
    def array_to_command(self,arr):
        #print(arr)
        #print(arr[1:])
        r=(self.command(arr[0],arr[1:],0x08))
        #print(r)
        return r
    def get_rssi_thresh(self):
        return self.get_property(0x20,0x01,0x4a)
    def set_rssi_thresh(self,val):
        self.set_property(0x20,0x4a,[val])
    def print_int_status(self,clear=True):
        answ = (self.get_int_status(clear=clear))
        #si4362.ba_map_array(answ,SiConst.MATRIX.GET_INT_STATUS_MAT)
        si4362.dict_print(ReplyTranslate.get_int_status(answ))
    def get_modem_status(self,clear=True):
        clr = [0xff]
        if clear:
            clr = []
        return self.command(0x22,clr,8)
    def print_modem_status(self,clear=True):
        si4362.dict_print(ReplyTranslate.get_modem_status(self.get_modem_status(clear=clear)))
    def print_chip_status(self):
        si4362.dict_print(ReplyTranslate.get_chip_status(self.command(0x23,[],5)))
    
    def get_ph_status(self,clear=True):
        clr = [0xff]
        if clear:
            clr=[]
        return self.command(0x21,clr,2)
    def print_ph_status(self,clear=True):
        answ = self.get_ph_status(clear=clear)
        si4362.dict_print(ReplyTranslate.get_ph_status(answ))
    def get_current_rssi(self):
        return self.get_modem_status()[2]
    def info(self,clear=True):
        sepinfo = "="*30
        septopic= "-"*30
        print(sepinfo)
        print("Int")
        print(septopic)
        self.print_int_status(clear=clear)
        print(septopic)
        print("Modem")
        print(septopic)
        self.print_modem_status()
        print(septopic)
        print("Packet")
        print(septopic)
        self.print_ph_status(clear=clear)
    def ticker(self,interval =1):
        print(clear)
        while True:
            time.sleep(interval)    
            self.info()
            print("\n\n")
    def get_gpio_status(self):
        print(self.command(0x13,[0x00],10))  
def command_info(chip,func=0,reset=False):
    radio  = chip
    if reset:
        radio.open()
        radio.reset()

    part_info = radio.part_info()
    print('Found Si%04x rev %d build %d id 0x%04x customer %d rom %d' % (
                            part_info['part'], part_info['chiprev'],
                            part_info['pbuild'], part_info['id'],
                            part_info['customer'], part_info['romid']))

    func_info = radio.func_info()
    print('Func: ext %d branch %d int %d patch %d func %d (%s)' % (
                            func_info['revext'], func_info['revbranch'],
                            func_info['revint'], func_info['patch'], func_info['func'],
                            func_info['image']))

    chip_status = radio.get_chip_status()
    print('Chip status: 0x%02x  Info flags: 0x%02x' % (
                            chip_status['chip_status'], chip_status['info_flags']))


    func_info = radio.func_info()
    print('Func: ext %d branch %d int %d patch %d func %d (%s)' % (
                            func_info['revext'], func_info['revbranch'],
                            func_info['revint'], func_info['patch'], func_info['func'],
                            func_info['image']))

    chip_status = radio.get_chip_status()
    print('Chip status: 0x%02x  Info flags: 0x%02x' % (
                            chip_status['chip_status'], chip_status['info_flags']))
    if reset:
        radio.close()
         
 
    

def give(with_setup=True):
    sdn = 23
    cts = 19 #21
    sck =14
    mosi = 13
    miso = 12
    sel = 15
    power_on = 32

    s = si4362(sdn=sdn,cts=cts,sck=sck,mosi=mosi,miso=miso,sel=sel,power_on=power_on)
    if with_setup:
        s.setup()
    #c1 = ccm.SiConf()
    s.tune()
    s.set_rssi_thresh(int(s.get_current_rssi()*1.1))
    #return s,c1
    return s


s = give()
s.clear_int()
import read 
read.call_func_clear = s.clear_int
print("finish")