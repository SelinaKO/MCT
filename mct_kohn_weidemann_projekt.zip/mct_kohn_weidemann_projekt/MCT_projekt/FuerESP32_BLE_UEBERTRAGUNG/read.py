import machine 
import crc_check
import blec 
import time 
ble = blec.bluetooth.BLE()
temp = blec.BLETemperature(ble)
import sixbitascii
#import ais_signal_to_data


# Nirq auf Platine, geht runter wenn RSSI-Jump etc
nirq = machine.Pin(34,machine.Pin.IN)
print("nirq init")
#Data in, GPIO 2 Makierung auf Platine, in Config drittes (0x14)
raw_data = machine.Pin(18,machine.Pin.PULL_DOWN)
print("rawdat init")

#Receive Data Clock, GPIO 0 Markierung auf Platine, in Config erstes (0x11) 
raw_data_clk = machine.Pin(17,machine.Pin.PULL_DOWN)
print("raw_dataclk init")

#Counter fuer die Schreib-Routine, schreibe rec_length
rec_length = 650
shots = 0
buffer = bytearray(rec_length)
payloads = []
process = False
print(3)


def string_to_eight_reverted_string(s):
    r = ""
    while s != "":
        t = list(s[:8])
        t.reverse()
        r+="".join(t)
        s=s[8:]
    return r

def bla():
    pass
call_func_clear = bla  

def sck_callback_on(p):
    global raw_data,shots, buffer,call_func_clear,sck_callback_off,temp
    if shots>0:
        buffer[rec_length-shots] = raw_data.value()
        shots-=1
        pass 
    if shots<=0:
        call_func_clear()
        #sck_callback_off(1)
def sck_callback_off(p):
    global shots,buffer ,payloads,rec_length,call_func_clear,nirq
    if shots != rec_length:
        shots = rec_length 
        un_nrzi = bytearray([1-(c^b) for (c,b) in zip(buffer[1:],buffer[:-1])])
        un_nrzi = bytes(un_nrzi)
        index = un_nrzi.find(bytes(bytearray([0,1,1,1,1,1,1,0])))
        first_cut = 0
        if index > -1:
            first_cut = un_nrzi[index+1:]
            index2 = first_cut.find(bytes(bytearray([0,1,1,1,1,1,1,0])))
            if index2 != -1: 
                payload = first_cut[7:index2]
                if len(payload)>184:
                    payloads.append(payload)
        if len(payloads) >= 1: 
            for i in payloads:
                k = i.replace(bytes(bytearray([1,1,1,1,1,0])),bytes(bytearray([1,1,1,1,1])))
                
                if len(k) in [420,418,420,422,416]:
                    
                    print("="*80)
                    print(k[:6])
                    print("".join([str(int(x)) for x in k]))
                    print("="*80)
                if len(k)%8==0:
                    
                    k = "".join([str(int(x)) for x in k])
                    #print(len(k))
                    #print("crc",crc_check.check(k))
                    if crc_check.check(k):
                        k = "!AIVDM,1,1,,A,"+sixbitascii.encode(string_to_eight_reverted_string(k))
                        temp.set_temperature(k, notify=i == 0, indicate=True)
                        print(k)
                        time.sleep(5)
                        temp.set_temperature("EOM", notify=i == 0, indicate=True)
                    else:
                        print("crc failed")

            payloads = []
        if not nirq.value():
            call_func_clear()
    #call_func_clear()

raw_data_clk.irq(trigger=machine.Pin.IRQ_FALLING,handler=None)
print(4)
on = False
def nirq_callback(p):
    global raw_data_clk,on
    if not p.value():
        raw_data_clk.irq(trigger=machine.Pin.IRQ_FALLING,handler=sck_callback_on)
        #print("+",end="")
        #on = True
    else:
        raw_data_clk.irq(trigger=machine.Pin.IRQ_FALLING,handler=sck_callback_off)
        #print("-",end="")
        on = False

print(5)
nirq.irq(trigger=machine.Pin.IRQ_RISING | machine.Pin.IRQ_FALLING,handler=nirq_callback)
print(6)