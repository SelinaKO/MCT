
# inais     matched zu chr()        bedeutung
# 0x00      0x40                    @
# 0x01      0x41
# bis...
# 0x01F     0x5F
#                                                                           ->  inais<32   matches chr(inais+64)
# 0x21          matched directly
# bis...
# 0x3f

def bits_to_six_ascii(x):
    if x < 32:
        return chr(x+64)
    if x < 64:
        return chr(x)
    return "error"


for i in range(33):
    print(bits_to_six_ascii(i), " ", i, " ", hex(i), " ", bin(i), " ",
          bits_to_six_ascii(i+33), " ", i+33, " ", hex(i+33), " ", bin(i+33), " ")

def aivdm_to_bits(aivdm):
    r = ""
    for i in aivdm:
        n = int.from_bytes(i.encode(),'big')
        n-=48
        if n >40:
            n-=8
        n+=64 
        r+=bin(n)[3:]
    return r


def whole_bs_decode(bs):
    iter = len(bs)//6
    r = ""
    for i in range(iter):
        r += bits_to_six_ascii(int(bs[i*6:i*6+6], 2))
    return r
def encode(bs):
    iter = len(bs)//6
    r = ""
    for i in range(iter):
        n = int(bs[i*6:i*6+6], 2)
        if n > 40:
            n+=8
        n += 48
        r+= chr(n)
    return r
        
        
    """
    @   0   0x0   0b0   !   33   0x21   0b100001  
A   1   0x1   0b1   "   34   0x22   0b100010  
B   2   0x2   0b10   #   35   0x23   0b100011  
C   3   0x3   0b11   $   36   0x24   0b100100  
D   4   0x4   0b100   %   37   0x25   0b100101  
E   5   0x5   0b101   &   38   0x26   0b100110  
F   6   0x6   0b110   '   39   0x27   0b100111  
G   7   0x7   0b111   (   40   0x28   0b101000  
H   8   0x8   0b1000   )   41   0x29   0b101001  
I   9   0x9   0b1001   *   42   0x2a   0b101010  
J   10   0xa   0b1010   +   43   0x2b   0b101011  
K   11   0xb   0b1011   ,   44   0x2c   0b101100  
L   12   0xc   0b1100   -   45   0x2d   0b101101  
M   13   0xd   0b1101   .   46   0x2e   0b101110  
N   14   0xe   0b1110   /   47   0x2f   0b101111  
O   15   0xf   0b1111   0   48   0x30   0b110000  
P   16   0x10   0b10000   1   49   0x31   0b110001  
Q   17   0x11   0b10001   2   50   0x32   0b110010  
R   18   0x12   0b10010   3   51   0x33   0b110011  
S   19   0x13   0b10011   4   52   0x34   0b110100  
T   20   0x14   0b10100   5   53   0x35   0b110101  
U   21   0x15   0b10101   6   54   0x36   0b110110  
V   22   0x16   0b10110   7   55   0x37   0b110111  
W   23   0x17   0b10111   8   56   0x38   0b111000  
X   24   0x18   0b11000   9   57   0x39   0b111001  
Y   25   0x19   0b11001   :   58   0x3a   0b111010  
Z   26   0x1a   0b11010   ;   59   0x3b   0b111011  
[   27   0x1b   0b11011   <   60   0x3c   0b111100  
\   28   0x1c   0b11100   =   61   0x3d   0b111101  
]   29   0x1d   0b11101   >   62   0x3e   0b111110  
^   30   0x1e   0b11110   ?   63   0x3f   0b111111  
_   31   0x1f   0b11111   error   64   0x40   0b1000000  
    32   0x20   0b100000   error   65   0x41   0b1000001  
"""
