# decode_nrzi
# to_eights
# arr_to_bin_string
# arr_to_bin_string
# unstuff
# arr_to_bin_string
# to_reverted_btyes
# arr_to_bin_string
# SIDEKICK 244150827
# get_payload
#byte_slice = slice(0,-1,8)
#kee[]
import sixbitascii
def ano(x):
    return
    print("="*30)
    print(x,end="\n")
def ibc(x):
    #print("I become\t",type(x[0]),type(x))
    pass


#keep
def decode_nrzi(arr):
    ano("decode_nrzi")
    ibc(arr)
    a = arr[:-1]
    b = arr[1:]
    # xor aufeinanderfolgende
    c = [i != j for i,j in zip(a,b)]
    d = [  int(not int(i)) for i in c]
    return d

startflag = [0,1,1,1,1,1,1,0]
#keep

def string_to_eight_reverted_string(s):
    r = "".join(["".join(list(s[i:i+8]).reverse()) for i in range(0, len(s), 8)])
    return r 
def unstuff_string(s):
    return s.replace("1111100","111110")

def zeropad_string(s):
    return s + "0"*(8-len(s)%8)

def around(arr):
    ano("around")
    #soll unstuff un revert bytes ersetsen
    #Ersetzte 1111100 mit 111110
    rs = string_to_eight_reverted_string(zeropad_string((unstuff_string(arr_to_bin_string(arr)))))
   #print("rs---->   ","AIVDM,1,1,,A,"+sixbitascii.whole_bs_decode(rs[:-16]))
    #print("rs---->","AIVDM,1,1,,A,"+sixbitascii.whole_bs_decode(arr[:-16]))
    print("AIVDM,1,1,,A,"+sixbitascii.whole_bs_decode(string_to_eight_reverted_string(arr)))
    print(arr)
    print(string_to_eight_reverted_string(arr))
    return rs
    #umdrehen 


def arr_to_bin_string(arr):
    ano("arr_to_bin_string!!!!!!!!!!!!!")
    ibc(arr)    
    try:
        return "".join(map(str,arr))
    except Exception as e:
        return "100000000000000000000000000000000000000000000000000000000000000000000000"


#keep
def to_eights(arr):
    ano("to_eights")
    ibc(arr)
    a = [arr[0+j:-1*j-1] for j in range(8)]
    return list(zip(*a))
#keep
def get_payload_and_crc(araw):
    ano("get_payload_and_crc")
    ibc(araw)
    arr = decode_nrzi(araw)
    a = to_eights(arr)
    r = 0
    c = 0
    start_in = None  
    for n, i in enumerate(a):
        if list(i) == [0,1,1,1,1,1,1,0]:
            r = arr[(n+8):(n+176)]
            c =  arr[n+176:n+192]
            break 
    arr = r 
    arr = list(map(int,list(arr_to_bin_string(arr).replace("1111100","111110"))))
    return arr , c


def payload_eval(pl):
    ano("payload_eval,messagetype")
    print("messagetype:",int(around(pl)[:6],2))
    return



def consume_signal(j,preprocessed=True):
    inr = [0]
    p,c = 0,0
    if not True:
        print("warning"*80)
        p,c = get_payload_and_crc(j)
    else:
        p = j[:-16]
        c = j[-16:]
    i = p+c
    return around(i)
    return payload_eval(p)
    try:
        #inr = arr_to_bin_string(to_reverted_bytes(unstuff(arr_to_bin_string(i))))
        #inr = arr_to_bin_string(to_reverted_bytes(unstuff(i)))
        #print("original",inr)
        inr = around(i)
        #print("around",inr)
    except Exception as e:
        pass
    if len(inr) >50:
            mmsi = int(int(inr[8:38][::],2))
            print("mmsi:",mmsi)
            return #mmsi
    



def single_arr_transform(i):
    ano("single_arr_transform")
    r = [] 
    k = [] 
    s = on_array(i)
    if len(s) >50:
        k.append(int(s[8:38][::],2))
    r.append(s)
    return k[0]

if __name__ == "__main__":
    print(zeropad_string("asdfghhh"))
    print(zeropad_string("asdfghhh")[byte_slice])
    print((string_to_eight_reverted_string(zeropad_string("asdddddddfasdg"))))
    print("hi")    #get_all_pc()
    #for j in sorted(all_transform()):
    #    print(j)
    #print([type(x[0]) for x in get_all_pc()])
    #getallpc
    #       [] von-> payload,crc in [int,int,int...] form 


#test_transform>get_all_pc>