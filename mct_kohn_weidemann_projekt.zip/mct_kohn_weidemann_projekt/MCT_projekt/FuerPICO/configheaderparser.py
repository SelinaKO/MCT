


def arr_produce(a):
    command_order = []
    command_dict = {} 
    for i in a:
        l = i.split(" ")
        var = l[1]
        values =  l[2:]
        values = [hex(int(x[:4],16)) for x in values]
        
        command_order.append(var)
        command_dict[var] = values
    return command_order, command_dict


def from_config_file(filename):
    a = []
    if filename[-2:]==".h":
        with open(filename,'r') as f:
            for l in f.readlines():
                if l[:10] == "#define RF":
                    a.append(l)
        return arr_produce(a)
    


if __name__=="__main__":
    a = []
    with open("standard_config.h",'r') as f:
        for l in f.readlines():
            if l[:10] == "#define RF":
                a.append(l)

    print(arr_produce(a))
